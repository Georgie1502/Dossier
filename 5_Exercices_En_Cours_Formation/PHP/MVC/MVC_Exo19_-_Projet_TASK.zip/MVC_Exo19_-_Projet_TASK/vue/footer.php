
     </ul>
        <input type="submit" value="Supprimer">
    </form>
</body>
</html>