<h3>EXERCICE BONUS</h3>
    <form action="" method="post">
        <ul>